/***************************************************/
The original MATLAB code can be downloaded from the following website:
	http://people.sissa.it/~laio/Research/Res_clustering.php
/***************************************************/
Here, some slight modifications are made for further empirical validations,
you can *freely* use them!
/***************************************************/
Ultimate End (UE):
	Just for Fun!
/***************************************************/
Author: DQQ.077
Email: 15012602873@163.com
Version: 1.2
Date: 2015-11-11
/***************************************************/



*******Demo*******
you will find a very simple demo for showing the usefulness of *DensityClust*

